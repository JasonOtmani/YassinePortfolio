# Thinkful TPM Portfolio Template
This portfolio template was created from existing CV and Portfolio templates, as an example of the types of static pages that students can build using basic HTML and CSS skills taught as part of the practical technology portion of Thinkful's Technical Project Management program.

Below, you will find links to resources that can help guide you through the process of customizing this portfolio, as well as links to the original templates that were used to create this one.

## Student resources
STUDENT RESOURCES GO HERE

### Template Sources:
This template was created from two free StartBootstrap templates:

 - Agency Theme: https://startbootstrap.com/themes/agency/
 - Resume Theme: https://startbootstrap.com/themes/resume/